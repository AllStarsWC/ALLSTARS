// ─────────────────────────────────────────────────────────────────────────────
// ALL STARS WC 2026 — Gacha Server
// Stack: Express + Socket.io + Solana Web3 (transaction verification)
// ─────────────────────────────────────────────────────────────────────────────

const express  = require('express');
const path     = require('path');
const http     = require('http');
const { Server } = require('socket.io');
const { Connection, PublicKey } = require('@solana/web3.js');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server);
const cards  = require('./cards.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─────────────────────────────────────────────────────────────────────────────
// !! CONFIGURE THESE BEFORE GOING LIVE !!
// Set these in Replit Secrets (padlock icon) — never hardcode in production
// ─────────────────────────────────────────────────────────────────────────────
const CONFIG = {
  TOKEN_MINT:      process.env.TOKEN_MINT      || 'YOUR_TOKEN_MINT_ADDRESS_HERE',
  TREASURY_WALLET: process.env.TREASURY_WALLET || 'YOUR_TREASURY_WALLET_HERE',
  PULL1_COST:      parseInt(process.env.PULL1_COST)  || 100_000_000,  // 100 tokens (6 decimals)
  PULL10_COST:     parseInt(process.env.PULL10_COST) || 900_000_000,  // 900 tokens
  FREE_MODE:       process.env.FREE_MODE === 'true' || false,         // true = no payment needed
  RPC_URL:         process.env.RPC_URL || 'https://api.mainnet-beta.solana.com',
};

console.log('─────────────────────────────────────');
console.log('⚽ ALL STARS WC 2026 GACHA');
console.log(`💰 Free mode:  ${CONFIG.FREE_MODE}`);
console.log(`🪙 Token mint: ${CONFIG.TOKEN_MINT}`);
console.log(`🏦 Treasury:   ${CONFIG.TREASURY_WALLET}`);
console.log(`🎰 Pull x1:    ${CONFIG.PULL1_COST  / 1_000_000} tokens`);
console.log(`🎰 Pull x10:   ${CONFIG.PULL10_COST / 1_000_000} tokens`);
console.log('─────────────────────────────────────');

const connection = new Connection(CONFIG.RPC_URL, 'confirmed');

// ─────────────────────────────────────────────────────────────────────────────
// In-memory store
// For persistence → swap with Replit DB: npm install @replit/database
// ─────────────────────────────────────────────────────────────────────────────
const pullLog        = [];
const collections    = {};       // { username: Set<cardId> }
const usedSignatures = new Set();// replay attack protection

// ─────────────────────────────────────────────────────────────────────────────
// Weighted random
// ─────────────────────────────────────────────────────────────────────────────
function weightedRandom(pool) {
  const total = pool.reduce((s, c) => s + c.weight, 0);
  let r = Math.random() * total;
  for (const card of pool) {
    r -= card.weight;
    if (r <= 0) return card;
  }
  return pool[pool.length - 1];
}

function pull10() {
  const results = [];
  let hasRarePlus = false;
  for (let i = 0; i < 10; i++) {
    let pool = cards;
    if (i === 9 && !hasRarePlus) pool = cards.filter(c => c.rarity !== 'common');
    const card = weightedRandom(pool);
    if (card.rarity !== 'common') hasRarePlus = true;
    results.push(card);
  }
  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Solana transaction verifier
// ─────────────────────────────────────────────────────────────────────────────
async function verifyTokenPayment(signature, expectedAmount) {
  try {
    if (usedSignatures.has(signature)) {
      console.warn(`[SECURITY] Replay attempt: ${signature}`);
      return { ok: false, reason: 'Transaction already used' };
    }

    const tx = await connection.getParsedTransaction(signature, {
      commitment: 'confirmed',
      maxSupportedTransactionVersion: 0,
    });

    if (!tx)        return { ok: false, reason: 'Transaction not found on-chain' };
    if (tx.meta?.err) return { ok: false, reason: 'Transaction failed on-chain' };

    // Reject transactions older than 5 minutes
    const age = Date.now() - (tx.blockTime || 0) * 1000;
    if (age > 5 * 60 * 1000) return { ok: false, reason: 'Transaction expired (max 5 min)' };

    // Scan instructions for a valid SPL token transfer
    for (const ix of tx.transaction.message.instructions) {
      if (!ix.parsed) continue;
      const { type, info } = ix.parsed;

      if (type === 'transferChecked' || type === 'transfer') {
        const mint      = info.mint        || '';
        const dest      = info.destination || '';
        const rawAmount = parseInt(info.tokenAmount?.amount ?? info.amount ?? '0');

        if (
          mint      === CONFIG.TOKEN_MINT &&
          dest      === CONFIG.TREASURY_WALLET &&
          rawAmount >= expectedAmount
        ) {
          usedSignatures.add(signature);
          return { ok: true };
        }
      }
    }

    return { ok: false, reason: 'No valid token transfer to treasury found' };
  } catch (err) {
    console.error('[verifyTokenPayment]', err.message);
    return { ok: false, reason: 'Verification error: ' + err.message };
  }
}

function recordPull(username, wallet, card) {
  pullLog.push({ username, wallet, card, timestamp: Date.now() });
  if (!collections[username]) collections[username] = new Set();
  collections[username].add(card.id);
}

// ─────────────────────────────────────────────────────────────────────────────
// Routes
// ─────────────────────────────────────────────────────────────────────────────

// Frontend reads this on load to know token mint + costs
app.get('/api/config', (req, res) => {
  res.json({
    tokenMint:      CONFIG.TOKEN_MINT,
    treasuryWallet: CONFIG.TREASURY_WALLET,
    pull1Cost:      CONFIG.PULL1_COST,
    pull10Cost:     CONFIG.PULL10_COST,
    pull1CostUI:    CONFIG.PULL1_COST  / 1_000_000,
    pull10CostUI:   CONFIG.PULL10_COST / 1_000_000,
    freeMode:       CONFIG.FREE_MODE,
  });
});

// Single pull
app.post('/api/pull', async (req, res) => {
  const { username = 'Anonymous', wallet, signature } = req.body;

  if (!CONFIG.FREE_MODE) {
    if (!wallet || !signature) return res.status(400).json({ error: 'Wallet and signature required' });
    const v = await verifyTokenPayment(signature, CONFIG.PULL1_COST);
    if (!v.ok) return res.status(400).json({ error: v.reason });
  }

  const card = weightedRandom(cards);
  recordPull(username, wallet || 'free', card);
  io.emit('pull-event', { username, card });
  res.json({ card });
});

// x10 pull
app.post('/api/pull/10', async (req, res) => {
  const { username = 'Anonymous', wallet, signature } = req.body;

  if (!CONFIG.FREE_MODE) {
    if (!wallet || !signature) return res.status(400).json({ error: 'Wallet and signature required' });
    const v = await verifyTokenPayment(signature, CONFIG.PULL10_COST);
    if (!v.ok) return res.status(400).json({ error: v.reason });
  }

  const results = pull10();
  results.forEach(card => recordPull(username, wallet || 'free', card));
  results
    .filter(c => c.rarity === 'legendary' || c.rarity === 'epic')
    .forEach(card => io.emit('pull-event', { username, card }));
  res.json({ cards: results });
});

app.get('/api/cards',            (req, res) => res.json(cards));
app.get('/api/collection/:user', (req, res) => res.json([...(collections[req.params.user] || new Set())]));
app.get('/api/feed',             (req, res) => res.json(pullLog.slice(-30).reverse()));

app.get('/api/leaderboard', (req, res) => {
  const board = Object.entries(collections)
    .map(([username, set]) => ({
      username,
      total: set.size,
      legendaries: [...set].filter(id => cards.find(c => c.id === id)?.rarity === 'legendary').length,
    }))
    .sort((a, b) => b.legendaries - a.legendaries || b.total - a.total)
    .slice(0, 20);
  res.json(board);
});

// ─────────────────────────────────────────────────────────────────────────────
// Socket.io — chat
// ─────────────────────────────────────────────────────────────────────────────
io.on('connection', socket => {
  socket.on('chat-message', ({ username, message }) => {
    const safe = String(message).replace(/</g,'&lt;').replace(/>/g,'&gt;').slice(0, 200);
    io.emit('chat-message', { username, message: safe, timestamp: Date.now() });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`\n🚀 http://localhost:${PORT}\n`));
