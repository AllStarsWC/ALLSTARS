# ⚽ All Stars WC 2026 — Gacha Machine

Animated trading card gacha machine for the 2026 FIFA World Cup All Stars.

## 🚀 Quick Start on Replit

1. **Upload** all files to a new Node.js Repl
2. Run `npm install` in the Shell tab
3. Hit **Run** — machine goes live at your Replit URL

## 📁 Project Structure

```
/
├── server.js          ← Express + Socket.io backend
├── cards.json         ← 100 player card definitions
├── package.json
├── .replit
└── public/
    ├── index.html     ← Full animated frontend
    └── cards/         ← YOUR card images go here
```

## 🖼️ Adding Your Card Images

Place your card design images in `/public/cards/` named exactly:
```
001.png   ← Messi
002.png   ← Ronaldo
003.png   ← Mbappé
... etc up to 100.png
```

If an image is missing, the machine shows the player's country flag emoji instead — so it works out of the box even with no images.

## 🃏 Rarity System

| Rarity    | Cards | Pull Weight | Approx Rate |
|-----------|-------|-------------|-------------|
| Legendary | 10    | 1 each      | ~1%         |
| Epic      | 20    | 5 each      | ~6%         |
| Rare      | 30    | 18 each     | ~19%        |
| Common    | 40    | 50 each     | ~74%        |

- **×10 Pull** guarantees at least 1 Rare or above
- Weights are adjustable in `cards.json`

## ✨ Features

- 🎰 Single & 10-pull with animated card flips
- ⭐ Confetti explosion for Legendary pulls
- 🔴 Live pull feed (Socket.io) — shows rare+ pulls from all users
- 💬 Live chat room
- 📚 Full 100-card collection viewer (locked/unlocked state)
- 🏆 Leaderboard ranked by legendaries then total cards
- 🎨 Filter collection by rarity
- 📊 Personal stats (pulls, owned, legendaries)

## ➕ Adding More Cards

Just add entries to `cards.json`:

```json
{
  "id": "101",
  "name": "New Player",
  "country": "Brazil",
  "position": "Forward",
  "rarity": "rare",
  "weight": 18,
  "image": "/cards/101.png",
  "flag": "🇧🇷"
}
```

No server restart needed if using nodemon.

## 🗄️ Persistent Storage (Optional Upgrade)

Currently uses in-memory storage (resets on restart).
To persist data, swap the `pullLog` and `collections` objects with:
- **Replit DB**: `npm install @replit/database` — key-value, zero config
- **SQLite**: `npm install better-sqlite3`
- **Supabase**: free Postgres with REST API
